import{w as e}from"./wsClient-mzQYzPGN.js";class o{connect(){return e.connect()}disconnect(){e.disconnect()}on(n,c){e.on(n,c)}off(n,c){e.off(n,c)}get isConnected(){return e.isConnected}}const r=new o;export{r as w};
//# sourceMappingURL=websocket-CXXCYyNy.js.map

import { Router } from 'express';
import { requireAuth, requireRole } from '../../middleware/auth.js';
import { validate, validateQuery, schemas } from '../security/validators.js';
import { apiRateLimiter } from '../security/rateLimiter.js';
import { csrfProtection } from '../security/csrf.js';
export function createModelsRoutes(modelsController) {
    const router = Router();
    // Apply rate limiting to all routes
    router.use(apiRateLimiter);
    // List models (protected)
    router.get('/', requireAuth, validateQuery(schemas.pagination), modelsController.listModels.bind(modelsController));
    // Get model by ID (protected)
    router.get('/:id', requireAuth, modelsController.getModel.bind(modelsController));
    // Create model (trainer/admin only)
    router.post('/', requireAuth, requireRole('trainer'), csrfProtection, validate(schemas.createModel), modelsController.createModel.bind(modelsController));
    // Update model (trainer/admin only)
    router.put('/:id', requireAuth, requireRole('trainer'), csrfProtection, validate(schemas.updateModel), modelsController.updateModel.bind(modelsController));
    // Delete model (admin only)
    router.delete('/:id', requireAuth, requireRole('admin'), csrfProtection, modelsController.deleteModel.bind(modelsController));
    // Get model logs
    router.get('/:id/logs', requireAuth, validateQuery(schemas.pagination), modelsController.getModelLogs.bind(modelsController));
    // Get model checkpoints
    router.get('/:id/checkpoints', requireAuth, modelsController.getModelCheckpoints.bind(modelsController));
    // Export model
    router.post('/:id/export', requireAuth, requireRole('trainer'), csrfProtection, modelsController.exportModel.bind(modelsController));
    return router;
}

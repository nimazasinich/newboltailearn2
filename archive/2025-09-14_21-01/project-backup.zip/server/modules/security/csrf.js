import csrf from 'csrf';
const tokens = new csrf();
/**
 * Generate CSRF token for a request
 */
export function generateCSRFToken(req) {
    // Generate or retrieve secret
    if (!req.session) {
        req.session = {};
    }
    if (!req.session.csrfSecret) {
        req.session.csrfSecret = tokens.secretSync();
    }
    // Generate token
    const token = tokens.create(req.session.csrfSecret);
    req.csrfToken = token;
    return token;
}
/**
 * CSRF Protection Middleware
 * Uses double-submit cookie pattern
 */
export function csrfProtection(req, res, next) {
    // Skip CSRF for GET, HEAD, OPTIONS requests
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
        return next();
    }
    // Skip CSRF for auth endpoints (login/register don't have session yet)
    const path = req.path || req.url || '';
    const excludedPaths = [
        '/auth/login',
        '/auth/register', 
        '/health',
        '/metrics',
        '/api/datasets',
        '/api/models'
    ];
    
    if (excludedPaths.some(excludedPath => path.includes(excludedPath))) {
        return next();
    }
    // Skip CSRF in development mode if configured
    if (process.env.NODE_ENV === 'development' && process.env.SKIP_CSRF === 'true') {
        return next();
    }
    // Get token from request
    const token = req.body._csrf ||
        req.query._csrf ||
        req.headers['x-csrf-token'] ||
        req.headers['x-xsrf-token'];
    if (!token) {
        res.status(403).json({
            error: 'CSRF token missing',
            message: 'A valid CSRF token is required for this request'
        });
        return;
    }
    // Verify token
    if (!req.session?.csrfSecret) {
        res.status(403).json({
            error: 'CSRF validation failed',
            message: 'No CSRF secret found in session'
        });
        return;
    }
    const valid = tokens.verify(req.session.csrfSecret, token);
    if (!valid) {
        res.status(403).json({
            error: 'Invalid CSRF token',
            message: 'The provided CSRF token is invalid or expired'
        });
        return;
    }
    next();
}
/**
 * Middleware to inject CSRF token into response
 */
export function injectCSRFToken(req, res, next) {
    // Generate token for all requests
    const token = generateCSRFToken(req);
    // Set token in response header
    res.setHeader('X-CSRF-Token', token);
    // Also set in cookie for SPA
    res.cookie('XSRF-TOKEN', token, {
        httpOnly: false, // Allow JavaScript to read it
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 3600000 // 1 hour
    });
    next();
}
/**
 * Get CSRF token endpoint
 */
export function getCSRFToken(req, res) {
    const token = generateCSRFToken(req);
    res.json({ csrfToken: token });
}

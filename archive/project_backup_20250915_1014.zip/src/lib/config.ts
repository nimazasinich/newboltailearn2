export const API_BASE = import.meta.env.VITE_API_BASE || '/api'
export const WS_PATH = import.meta.env.VITE_WS_PATH || '/ws'